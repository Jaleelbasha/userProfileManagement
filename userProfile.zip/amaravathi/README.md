MEAN stack for user profile.


Installation / Deployment

1. NodeJS (Server) : cd server

    2. npm install

    3. npm start

4. Angular 2 (Client) : cd client

    5. npm install

    6. npm start

7. Install local Mongodb and compass software