"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var index_1 = require("../_services/index");
var index_2 = require("../_services/index");
var HomeComponent = /** @class */ (function () {
    function HomeComponent(userService, authenticationService, alertService) {
        this.userService = userService;
        this.authenticationService = authenticationService;
        this.alertService = alertService;
        this.profile = {};
        this.selected_profile = {};
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }
    HomeComponent.prototype.ngOnInit = function () {
        this.ngOnChanges();
    };
    HomeComponent.prototype.ngOnChanges = function () {
        this.loadAllprofiles(this.currentUser._id);
    };
    HomeComponent.prototype.loadAllprofiles = function (id) {
        var _this = this;
        this.userService.getAllprofiles(id).subscribe(function (res) { _this.allProfiles = res; });
    };
    HomeComponent.prototype.createProfile = function () {
        this.selected_profile = {};
        $("#myModal").modal('toggle');
    };
    HomeComponent.prototype.submitprofile = function () {
        var _this = this;
        this.profile = this.selected_profile;
        this.profile["id"] = this.currentUser._id;
        console.log(this.profile);
        if (this.profile["company"].length > 0
            && this.profile["city"].length > 0
            && this.profile["salary"].length > 0
            && this.profile["designation"].length > 0
            && this.profile["year"].length > 0) {
            if (!this.selected_profile["_id"]) {
                this.userService.createProfile(this.profile).subscribe(function (res) {
                    _this.loadAllprofiles(_this.currentUser._id);
                    _this.alertService.success("New Profile Added");
                });
            }
            else {
                this.userService.editProfile(this.profile).subscribe(function () { _this.loadAllprofiles(_this.currentUser._id); });
            }
        }
        else {
            this.alertService.error("Please enter all feilds");
        }
        $("#myModal").modal('toggle');
    };
    HomeComponent.prototype.deleteProfile = function (data) {
        var _this = this;
        this.userService.deleteProfile(data._id).subscribe(function () { _this.loadAllprofiles(_this.currentUser._id); });
    };
    HomeComponent.prototype.editProfile = function (data) {
        this.selected_profile = data;
        $("#myModal").modal('toggle');
    };
    HomeComponent = __decorate([
        core_1.Component({
            moduleId: module.id,
            templateUrl: 'home.component.html'
        }),
        __metadata("design:paramtypes", [index_1.UserService, index_2.AuthenticationService,
            index_2.AlertService])
    ], HomeComponent);
    return HomeComponent;
}());
exports.HomeComponent = HomeComponent;
//# sourceMappingURL=home.component.js.map