﻿export const appConfig = {
    apiUrl: 'http://localhost:4000'
};